# wordpress-custom-endpoint
A free wordpress plugin with custom endpoints for wordpress blog. You can use React, Svelte or any other framework to retrieve posts and other contents.

> Not recommend to use in production right now!
