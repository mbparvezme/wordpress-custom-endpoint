<?php
// loader.php

// Load all dependencies
require_once plugin_dir_path(__FILE__) . 'wp-custom-endpoint-setting.php';
require_once plugin_dir_path(__FILE__) . 'wp-custom-endpoint-utility.php';
require_once plugin_dir_path(__FILE__) . 'wp-custom-endpoint.php';